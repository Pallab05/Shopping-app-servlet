package linkcodeMart.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import linkcodeMart.dao.UserDAO;
import linkcodeMart.model.Categories;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class FootwearController
 */
public class FootwearController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FootwearController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		Categories cat=new Categories();
		cat.setCategory_code(101);
		
		UserDAO udao=new UserDAO();
		
		ResultSet rs=udao.getProduct(cat);
		
		try {
			if(rs.next()) {
				HttpSession session=request.getSession();
				session.setAttribute("productData", rs);
				response.sendRedirect("ProductList.jsp");
			}
		} catch (SQLException e) {
		System.out.println(e);
		}
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
