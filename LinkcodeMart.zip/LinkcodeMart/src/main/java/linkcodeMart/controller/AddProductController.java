package linkcodeMart.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import linkcodeMart.dao.AdminDAO;
import linkcodeMart.model.Product;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class AddProductController
 */
@MultipartConfig
public class AddProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
    public AddProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("in Add product Controller");
		Part file=request.getPart("product_image");
		
		String imageFileName=file.getSubmittedFileName();
		System.out.println(imageFileName);
		
		String uploadPath="D:/web_workspace/LinkcodeMart/src/main/webapp/WEB-INF/images/"+imageFileName;
		System.out.println(uploadPath);
		
		FileOutputStream fos=new FileOutputStream(uploadPath);
		InputStream is=file.getInputStream();
		
		byte[] data=new byte[is.available()];
		is.read(data);
		fos.write(data);
		fos.close();
		
		String prod_name=request.getParameter("product_name");
		int prod_price=Integer.parseInt(request.getParameter("product_price"));
		int prod_code=Integer.parseInt(request.getParameter("product_code"));
		int prod_stock=Integer.parseInt(request.getParameter("product_stock"));
		String prod_brand=request.getParameter("product_brand");
		int prod_category_code=Integer.parseInt(request.getParameter("product_category_code"));
		
		Product product=new Product();
		product.setProduct_name(prod_name);
		product.setProduct_price(prod_price);
		product.setProduct_code(prod_code);
		product.setProduct_stock(prod_stock);
		product.setProduct_brand(prod_brand);
		product.setProduct_category_code(prod_category_code);
		product.setProduct_image(imageFileName);
		
		List<Product> prodList=new ArrayList<Product>();
		prodList.add(product);
		
		String status="Product Added";
		
		AdminDAO adao=new AdminDAO();
		int i= adao.addProduct(prodList);
		
		if(i>0) {
			System.out.println("Product Added");
			
			HttpSession session=request.getSession();
			session.setAttribute("status", session);
			response.sendRedirect("AdminDashboard.jsp");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
