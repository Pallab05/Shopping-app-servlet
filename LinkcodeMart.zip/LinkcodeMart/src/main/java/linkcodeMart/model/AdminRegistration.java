package linkcodeMart.model;

public class AdminRegistration {

	String admin_name;
	String admin_mobno;
	String admin_uname;
	String admin_pass;
	int admin_id;
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getAdmin_mobno() {
		return admin_mobno;
	}
	public void setAdmin_mobno(String admin_mobno) {
		this.admin_mobno = admin_mobno;
	}
	public String getAdmin_uname() {
		return admin_uname;
	}
	public void setAdmin_uname(String admin_uname) {
		this.admin_uname = admin_uname;
	}
	public String getAdmin_pass() {
		return admin_pass;
	}
	public void setAdmin_pass(String admin_pass) {
		this.admin_pass = admin_pass;
	}
	public int getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}
	public AdminRegistration(String admin_name, String admin_mobno, String admin_uname, String admin_pass,
			int admin_id) {
		super();
		this.admin_name = admin_name;
		this.admin_mobno = admin_mobno;
		this.admin_uname = admin_uname;
		this.admin_pass = admin_pass;
		this.admin_id = admin_id;
	}
	public AdminRegistration() {
		}
	
	
	
}
