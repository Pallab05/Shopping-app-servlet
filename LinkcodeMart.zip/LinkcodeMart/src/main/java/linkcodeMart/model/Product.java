package linkcodeMart.model;

public class Product {
	
	private String product_name;
	private int product_price;
	private int product_code;
	private int product_stock;
	private String product_brand;
	private int product_category_code;
	private String product_image;
	
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getProduct_price() {
		return product_price;
	}
	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}
	public int getProduct_code() {
		return product_code;
	}
	public void setProduct_code(int product_code) {
		this.product_code = product_code;
	}
	public int getProduct_stock() {
		return product_stock;
	}
	public void setProduct_stock(int product_stock) {
		this.product_stock = product_stock;
	}
	public String getProduct_brand() {
		return product_brand;
	}
	public void setProduct_brand(String product_brand) {
		this.product_brand = product_brand;
	}
	public int getProduct_category_code() {
		return product_category_code;
	}
	public void setProduct_category_code(int product_category_code) {
		this.product_category_code = product_category_code;
	}
	public String getProduct_image() {
		return product_image;
	}
	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}
	
	public Product(String product_name, int product_price, int product_code, int product_stock, String product_brand,
			int product_category_code, String product_image) {
		super();
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_code = product_code;
		this.product_stock = product_stock;
		this.product_brand = product_brand;
		this.product_category_code = product_category_code;
		this.product_image = product_image;
	}
	public Product() {
		
	}

	
}
