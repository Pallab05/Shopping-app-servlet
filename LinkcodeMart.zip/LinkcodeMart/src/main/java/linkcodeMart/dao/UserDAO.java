package linkcodeMart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import linkcodeMart.connection.MyConnection;
import linkcodeMart.model.Categories;

public class UserDAO {

	MyConnection mycon=new MyConnection();
	Connection con=null; 
	
	public ResultSet getProduct(Categories cat) {
		
		Categories category=cat;
		con=mycon.getConnection();
		System.out.println(con);
		
		ResultSet rs=null;
		
		try {
			PreparedStatement ps=con.prepareStatement("select* from product where product_category_code=?");
			ps.setInt(1, category.getCategory_code());
			rs=ps.executeQuery();
			if(rs.next()) {
				System.out.println("Products Found");
			}else {
				System.out.println("Product not found");
			}
		} catch (SQLException e) {
		System.out.println(e);
		}
		return rs;
	}
	
}
