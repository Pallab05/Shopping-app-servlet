package linkcodeMart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import linkcodeMart.connection.MyConnection;
import linkcodeMart.model.AdminRegistration;
import linkcodeMart.model.Product;

public class AdminDAO {

	static Connection con;
	MyConnection mycon=new MyConnection();
	
	public int saveAdminData(List<AdminRegistration> adminList) {
		
		List<AdminRegistration> adminlist=new ArrayList<AdminRegistration>();
		adminlist=adminList;
		AdminRegistration adreg=new AdminRegistration();
		adreg=adminlist.get(0);
		int i=0;
		
		con=mycon.getConnection();
		System.out.println(con);
		
		try {
			PreparedStatement ps=con.prepareStatement("insert into Admin values (?,?,?,?,admin_id.nextval)");
			ps.setString(1,adreg.getAdmin_name());
			ps.setString(2,adreg.getAdmin_mobno());
			ps.setString(3,adreg.getAdmin_uname());
			ps.setString(4,adreg.getAdmin_pass());
			
			i=ps.executeUpdate();
			
			
			
			
		} catch (SQLException e) {
			System.out.println(e);
		}
		return i;
	}
	
	public ResultSet adminValidation(List<AdminRegistration> adminList) {
		
		List<AdminRegistration> admlist=new ArrayList<AdminRegistration>();
		admlist=adminList;
		ResultSet rs=null;
		
		AdminRegistration adreg=new AdminRegistration();
		
		adreg=admlist.get(0);
		
		con=mycon.getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement("select* from admin where USERNAME=? and PASSWORD=?");
			ps.setString(1, adreg.getAdmin_uname());
			ps.setString(2,adreg.getAdmin_pass());
			
			 rs=ps.executeQuery();
		
		} catch (Exception e) {
			System.out.println(e);

		}
		
		return rs;
		
	}
	
	public int addProduct(List<Product> prodList) {
		
		List<Product> prod_list=prodList;
		
		int i=0;
		
		Product product=new Product();
		
		product=prod_list.get(0);
		
		con=mycon.getConnection();
		
		try {
			PreparedStatement ps=con.prepareStatement("insert into product values(?,?,?,?,?,?,?)");
			ps.setString(1, product.getProduct_name());
			ps.setInt(2, product.getProduct_price());
			ps.setInt(3, product.getProduct_code());
			ps.setInt(4, product.getProduct_stock());
			ps.setString(5, product.getProduct_brand());
			ps.setInt(6, product.getProduct_category_code());
			ps.setString(7, product.getProduct_image());
			
			i=ps.executeUpdate();
			
			
		} catch (SQLException e) {

			System.out.println(e);
		}
		return i;
	}
}
