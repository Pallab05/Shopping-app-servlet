function footwearProductList(){
    location.href="FootwearController";
}