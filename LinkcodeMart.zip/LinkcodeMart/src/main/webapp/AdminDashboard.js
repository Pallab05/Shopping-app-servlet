function addProduct(){
    location.href="AdminAddProduct.jsp";
}